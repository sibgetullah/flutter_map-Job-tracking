How to get more ".so" chipset builds:
 
   :: Warning 1: Your Lazarus/Freepascal needs to be prepared [cross-compile] for the various chipset builds!
   :: Warning 2: Laz4Android [out-of-box] support only 32 Bits chipset: "armV6", "armV7a+Soft", "x86"!
 
1. From LazarusIDE menu:
 
   > Project -> Project Options -> Project Options -> [LAMW] Android Project Options -> "Build" -> Chipset [select!] -> [OK]
 
2. From LazarusIDE  menu:
 
   > Run -> Clean up and Build...
 
3. From LazarusIDE menu:
 
   > [LAMW] Build Android Apk and Run
 
